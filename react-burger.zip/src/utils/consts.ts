export const url: string = 'https://norma.nomoreparties.space/api/';
